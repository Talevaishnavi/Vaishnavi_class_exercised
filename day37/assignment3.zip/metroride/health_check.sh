#!/bin/bash

echo "Disk Usage"
df -h

echo "Memory Usage"
free -h

echo "Java Processes"
jps