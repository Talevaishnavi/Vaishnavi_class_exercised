# MetroRide API

## Run using Maven

.\mvnw.cmd spring-boot:run

## Run using Gradle

gradle bootRun

## Sample API Endpoint

## Jenkins Pipeline Stages

- Checkout
- Maven Build
- Archive JAR
- Docker Build
- Docker Push

## Docker Commands

docker build -t metroride .

docker run -p 8080:8080 metroride

## Docker Compose

docker-compose up