# Contributing

## Branch Naming Rules

feature/*
bugfix/*
hotfix/*

## Commit Message Format

feat: add feature

fix: fix bug

docs: update documentation

## Merge Request Guidelines

1. Create a feature branch
2. Commit changes
3. Push code
4. Create pull request
5. Get approval
6. Merge into main