package com.metroride.metroride;

import org.springframework.web.bind.annotation.*;

@RestController
public class MetroController {

    @GetMapping("/metro")
    public String metro() {
        return "Next Metro arrives in 5 minutes";
    }
}